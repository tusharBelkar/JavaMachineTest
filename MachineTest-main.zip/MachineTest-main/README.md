# MachineTest
Category-Product CRUD operation
